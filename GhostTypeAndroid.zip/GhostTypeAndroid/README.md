# GhostType pour Android

Clavier Android (IME) qui affiche, **en gris clair**, la suite probable de ce que vous tapez (6 mots maximum). Un appui sur la suggestion l'insère ; **✕** l'ignore. Rien n'est écrit dans le champ avant l'acceptation.

100 % local : l'application **ne demande aucune permission** (pas d'INTERNET), ne contient aucune télémétrie, aucun compte, aucun rapport d'incident. Le modèle est une base SQLite privée construite à partir de vos fichiers `.txt` / `.md`.

> ⚠️ Écrit sans pouvoir être compilé (pas d'Android SDK à disposition). Attendez-vous à corriger quelques erreurs de compilation au premier build.

## Obtenir l'APK (GitHub)
1. Mettez ce projet (ou `GhostTypeAndroid.zip`) dans un dépôt GitHub, avec `.github/workflows/build.yml`.
2. Onglet **Actions** → **Build GhostType (Android)** → **Run workflow**.
3. Quand le run est vert : **Releases** (page principale du dépôt) → téléchargez `app-debug.apk`.

## Installer et activer
1. Ouvrez l'APK, autorisez « installer depuis cette source » si Android le demande.
2. Ouvrez **GhostType** : choisissez le **dossier de vos textes** (il se construit tout de suite ; touchez « Reconstruire » après l'avoir modifié).
3. « Ouvrir les réglages des claviers » → activez **GhostType**.
4. « Choisir GhostType comme clavier » → sélectionnez-le. Essayez dans la zone d'essai.

## Différences avec la version Mac
- Pas de Tab/Échap sur téléphone : on **touche la suggestion** pour accepter, **✕** pour ignorer.
- Le texte fantôme est dans la barre du clavier (Android ne permet pas de dessiner par-dessus le champ d'une autre app sans permission d'affichage).
- Moteur n-gramme uniquement (pas de serveur local) : sans INTERNET, aucune requête réseau n'est possible.
- Clavier AZERTY simple : accents via la touche **?123** (é è ê à ù ç ô), pas d'appui long.
- Corpus limité à 6 Mo de texte (mémoire d'un téléphone).

## Sécurité (non négociable)
Le clavier **ne lit aucun texte** et ne prédit rien quand le champ est : mot de passe (texte, visible, web, numérique), e-mail, URL, « sans suggestions », en **mode privé** (incognito), ou quand l'application est dans la **liste de refus** (modifiable ; par défaut : gestionnaires de mots de passe). Le motif s'affiche dans la barre du clavier. Pas de prédiction non plus en fin de champ si du texte suit le curseur sur la même ligne, ni quand du texte est sélectionné.

## Structure
```
app/src/main/java/com/ghosttype/android/
  GhostTypeService.kt  clavier, boucle 120 ms → lecture 200 caractères → suggestion
  KeyboardView.kt      clavier AZERTY dessiné en code + barre de suggestion
  Predictor.kt         n-grammes (repli trigramme → bigramme), 6 mots max
  NGramStore.kt        base SQLite privée      Corpus.kt  construction depuis le dossier
  Safety.kt            champs protégés, liste de refus   Prefs.kt  réglages locaux
  MainActivity.kt      écran de réglages
```

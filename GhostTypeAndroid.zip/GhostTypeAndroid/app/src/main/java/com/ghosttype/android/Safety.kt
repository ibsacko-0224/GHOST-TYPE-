package com.ghosttype.android

import android.text.InputType
import android.view.inputmethod.EditorInfo

object Safety {
    /** Applications ignorées par défaut (modifiable) : gestionnaires de mots de passe, authentificateurs. */
    val defaultDenylist: Set<String> = setOf(
        "com.x8bit.bitwarden",
        "com.agilebits.onepassword",
        "com.lastpass.lpandroid",
        "com.google.android.apps.authenticator2",
        "com.kunzisoft.keepass.free",
        "org.keepassxc.android",
    )

    private val protectedVariations = setOf(
        InputType.TYPE_TEXT_VARIATION_PASSWORD,
        InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
        InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD,
        InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS,
        InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS,
        InputType.TYPE_TEXT_VARIATION_URI,
    )

    /**
     * Retourne null si la prédiction est autorisée, sinon le motif (affiché dans la barre du clavier).
     * Quand un motif est retourné, le clavier ne lit AUCUN texte du champ.
     */
    fun blockReason(info: EditorInfo?, denylist: Set<String>): String? {
        if (info == null) return "Aucun champ"
        val type = info.inputType
        val cls = type and InputType.TYPE_MASK_CLASS
        val variation = type and InputType.TYPE_MASK_VARIATION
        if (cls == InputType.TYPE_NULL) return "Prédiction désactivée ici"
        if (cls == InputType.TYPE_CLASS_NUMBER && variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD) {
            return "Champ protégé : prédiction désactivée"
        }
        if (cls != InputType.TYPE_CLASS_TEXT) return "Prédiction désactivée ici"
        if (variation in protectedVariations) return "Champ protégé : prédiction désactivée"
        if (type and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS != 0) return "Prédiction désactivée ici"
        if (info.imeOptions and EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING != 0) return "Mode privé : prédiction désactivée"
        if (info.packageName != null && info.packageName in denylist) return "Application ignorée"
        return null
    }
}

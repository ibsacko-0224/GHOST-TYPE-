package com.ghosttype.android

import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import java.util.concurrent.Executors

/**
 * Clavier GhostType. À chaque frappe : délai de 120 ms → lecture des 200 derniers caractères avant le curseur
 * → suggestion (6 mots max) affichée en gris dans la barre du clavier. Un appui sur la suggestion l'insère ;
 * ✕ l'ignore. Rien n'est écrit dans le champ tant que la suggestion n'est pas acceptée.
 */
class GhostTypeService : InputMethodService() {

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var ui: KeyboardView? = null
    private lateinit var predictor: Predictor

    @Volatile private var generation = 0
    private var allowed = false
    private var suggestion: String? = null
    private val debounce = Runnable { predictNow() }

    override fun onCreate() {
        super.onCreate()
        predictor = Predictor(NGramStore(this))
    }

    override fun onDestroy() {
        worker.shutdownNow()
        main.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        val v = KeyboardView(this, object : KeyboardView.Listener {
            override fun onText(text: String) {
                currentInputConnection?.commitText(text, 1)
                refresh()
            }
            override fun onBackspace() {
                sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
                refresh()
            }
            override fun onEnter() = handleEnter()
            override fun onAccept() = accept()
            override fun onDismiss() = cancel()
        })
        ui = v
        return v
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        cancel()
        ui?.clearSuggestion()
        val reason = if (!Prefs.enabled(this)) "Prédiction désactivée" else Safety.blockReason(info, Prefs.denylist(this))
        allowed = reason == null
        if (reason != null) ui?.showNote(reason)
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        cancel()
        super.onFinishInputView(finishingInput)
    }

    /** L'application a déplacé le curseur ou changé le texte : la suggestion affichée est périmée. */
    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        refresh()
    }

    private fun handleEnter() {
        val info = currentInputEditorInfo
        val action = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noEnterAction = ((info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noEnterAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            currentInputConnection?.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
        refresh()
    }

    // ───────── Boucle de prédiction

    private fun cancel() {
        generation++
        main.removeCallbacks(debounce)
        suggestion = null
        if (allowed) ui?.clearSuggestion()      // dans un champ bloqué, le motif reste affiché
    }

    private fun refresh() {
        cancel()
        if (allowed) main.postDelayed(debounce, 120)
    }

    private fun predictNow() {
        if (!allowed) return
        val ic = currentInputConnection ?: return
        // Lecture seule, et seulement après les contrôles de sécurité de onStartInputView.
        if (!ic.getSelectedText(0).isNullOrEmpty()) return
        val after = ic.getTextAfterCursor(1, 0)?.toString()
        if (!after.isNullOrEmpty() && after[0] != '\n') return            // curseur en fin de ligne uniquement
        val before = ic.getTextBeforeCursor(200, 0)?.toString() ?: return
        if (before.isBlank()) return

        val gen = generation
        worker.execute {
            val raw = try { predictor.complete(before) { gen != generation } } catch (e: Exception) { null }
            val clean = raw?.let { Suggestion.clean(it, before) }
            main.post {
                if (gen == generation && allowed && clean != null) {
                    suggestion = clean
                    ui?.showSuggestion(before.takeLast(18), clean)
                }
            }
        }
    }

    private fun accept() {
        val s = suggestion ?: return
        generation++
        suggestion = null
        ui?.clearSuggestion()
        currentInputConnection?.commitText(s, 1)
    }
}

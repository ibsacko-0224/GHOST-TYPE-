package com.ghosttype.android

/** Découpage en mots/phrases et nettoyage des suggestions. Logique pure. */
object Tokenizer {
    private val boundaries = setOf('.', '!', '?', '\n', '\r', ';', ':', '…')

    fun isWordChar(c: Char) = c.isLetterOrDigit() || c == '\'' || c == '’' || c == '-'

    /** Phrases → mots en minuscules (les frontières de phrase ne sont jamais franchies). */
    fun segments(text: String): List<List<String>> {
        val result = ArrayList<List<String>>()
        var seg = ArrayList<String>()
        val cur = StringBuilder()
        fun flushWord() {
            val w = cur.toString().trim('-', '\'', '’')
            if (w.isNotEmpty() && w.any { it.isLetterOrDigit() }) seg.add(w.lowercase())
            cur.setLength(0)
        }
        fun flushSegment() {
            flushWord()
            if (seg.isNotEmpty()) {
                result.add(seg)
                seg = ArrayList()
            }
        }
        for (ch in text) {
            when {
                isWordChar(ch) -> cur.append(ch)
                ch in boundaries -> flushSegment()
                else -> flushWord()
            }
        }
        flushSegment()
        return result
    }

    /** Mots de la phrase en cours ([] si le texte se termine par une frontière de phrase). */
    fun currentWords(before: String): List<String> {
        var i = before.length
        while (i > 0) {
            val c = before[i - 1]
            if (c == ' ' || c == '\t') { i--; continue }
            if (c in boundaries) return emptyList()
            break
        }
        return segments(before).lastOrNull() ?: emptyList()
    }

    fun endsInsideWord(s: String) = s.isNotEmpty() && isWordChar(s.last())
}

object Suggestion {
    const val MAX_WORDS = 6

    /** Une seule ligne, 6 mots maximum. null si rien d'exploitable. */
    fun clean(raw: String, context: String): String? {
        var s = raw.replace("\r", "")
        val nl = s.indexOf('\n')
        if (nl >= 0) s = s.substring(0, nl)
        val lead = s.takeWhile { it == ' ' || it == '\t' }
        val words = s.split(' ', '\t').filter { it.isNotEmpty() }.take(MAX_WORDS)
        if (words.isEmpty()) return null
        var out = (if (lead.isEmpty()) "" else " ") + words.joinToString(" ")
        if ((context.endsWith(" ") || context.endsWith("\t")) && out.startsWith(" ")) out = out.substring(1)
        return out.ifEmpty { null }
    }
}

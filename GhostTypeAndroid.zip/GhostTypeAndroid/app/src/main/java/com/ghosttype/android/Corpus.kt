package com.ghosttype.android

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.time.Instant

/** Construit le modèle n-gramme à partir d'un dossier .txt / .md choisi par l'utilisateur (sélecteur système). */
object Corpus {
    data class Stats(val files: Int, val words: Int, val entries: Int)

    private const val MAX_FILE_BYTES = 2 * 1024 * 1024
    private const val MAX_TOTAL_BYTES = 6 * 1024 * 1024   // un téléphone a moins de mémoire qu'un Mac
    private const val MAX_FILES = 3000

    private fun listFiles(resolver: ContentResolver, tree: Uri): List<Uri> {
        val out = ArrayList<Uri>()
        val queue = ArrayDeque<String>()
        queue.add(DocumentsContract.getTreeDocumentId(tree))
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        while (queue.isNotEmpty() && out.size < MAX_FILES) {
            val id = queue.removeFirst()
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, id)
            resolver.query(children, cols, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val docId = c.getString(0)
                    val name = c.getString(1) ?: ""
                    if (name.startsWith(".")) continue
                    if (c.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR) {
                        queue.add(docId)
                    } else if (name.endsWith(".txt", true) || name.endsWith(".md", true)) {
                        out.add(DocumentsContract.buildDocumentUriUsingTree(tree, docId))
                    }
                }
            }
        }
        return out
    }

    private fun readLimited(s: InputStream, max: Int): ByteArray? {
        val buf = ByteArrayOutputStream()
        val tmp = ByteArray(8192)
        var total = 0
        while (true) {
            val n = s.read(tmp)
            if (n < 0) break
            total += n
            if (total > max) return null
            buf.write(tmp, 0, n)
        }
        return buf.toByteArray()
    }

    fun build(context: Context, tree: Uri, store: NGramStore, progress: (String) -> Unit): Stats {
        val resolver = context.contentResolver
        val files = listFiles(resolver, tree)
        val counts = HashMap<String, Int>()
        var total = 0
        var used = 0
        var words = 0
        for ((i, uri) in files.withIndex()) {
            progress("Lecture ${i + 1}/${files.size}…")
            val data = try {
                resolver.openInputStream(uri)?.use { readLimited(it, MAX_FILE_BYTES) }
            } catch (e: Exception) { null } ?: continue
            if (total + data.size > MAX_TOTAL_BYTES) continue
            total += data.size
            used++
            for (seg in Tokenizer.segments(String(data, Charsets.UTF_8))) {
                for (j in seg.indices) {
                    words++
                    val next = seg[j]
                    bump(counts, "\u001F$next")
                    if (j >= 1) bump(counts, seg[j - 1] + "\u001F" + next)
                    if (j >= 2) bump(counts, seg[j - 2] + " " + seg[j - 1] + "\u001F" + next)
                }
            }
        }
        progress("Écriture de ${counts.size} entrées…")
        store.replaceAll(
            counts,
            mapOf(
                "built_at" to Instant.now().toString(),
                "corpus" to tree.toString(),
                "files" to used.toString(),
                "words" to words.toString()
            )
        )
        return Stats(used, words, counts.size)
    }

    private fun bump(m: HashMap<String, Int>, key: String) {
        m[key] = (m[key] ?: 0) + 1
    }
}

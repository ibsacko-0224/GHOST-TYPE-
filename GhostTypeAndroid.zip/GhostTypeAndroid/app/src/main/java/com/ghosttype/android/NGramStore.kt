package com.ghosttype.android

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * Magasin de n-grammes (ordre 1 à 3) dans la base privée de l'application.
 * ctx = 0, 1 ou 2 mots précédents séparés par une espace ; next = mot suivant.
 */
class NGramStore(context: Context) : SQLiteOpenHelper(context.applicationContext, "ngram.db", null, 1) {

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.enableWriteAheadLogging()   // le clavier peut lire pendant une reconstruction
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE meta(key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        db.execSQL(
            "CREATE TABLE ngram(ctx TEXT NOT NULL, next TEXT NOT NULL, count INTEGER NOT NULL, " +
                "PRIMARY KEY(ctx, next)) WITHOUT ROWID"
        )
        db.execSQL("CREATE INDEX ngram_ctx_count ON ngram(ctx, count DESC)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun meta(key: String): String? =
        readableDatabase.rawQuery("SELECT value FROM meta WHERE key = ?", arrayOf(key)).use {
            if (it.moveToFirst()) it.getString(0) else null
        }

    val isBuilt: Boolean get() = meta("built_at") != null

    fun bestNext(ctx: String, minCount: Int): String? =
        readableDatabase.rawQuery(
            "SELECT next FROM ngram WHERE ctx = ? AND count >= $minCount ORDER BY count DESC LIMIT 1",
            arrayOf(ctx)
        ).use { if (it.moveToFirst()) it.getString(0) else null }

    /** Mot le plus fréquent qui commence par [prefix] et est strictement plus long. */
    fun bestWord(ctx: String, prefix: String, minCount: Int): String? =
        readableDatabase.rawQuery(
            "SELECT next FROM ngram WHERE ctx = ? AND next > ? AND next < ? AND count >= $minCount " +
                "ORDER BY count DESC LIMIT 1",
            arrayOf(ctx, prefix, prefix + "\uFFFF")
        ).use { if (it.moveToFirst()) it.getString(0) else null }

    fun replaceAll(counts: Map<String, Int>, meta: Map<String, String>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.execSQL("DELETE FROM ngram")
            db.execSQL("DELETE FROM meta")
            val ins = db.compileStatement("INSERT INTO ngram(ctx, next, count) VALUES(?, ?, ?)")
            for ((key, n) in counts) {
                val sep = key.indexOf('\u001F')
                if (sep < 0) continue
                ins.clearBindings()
                ins.bindString(1, key.substring(0, sep))
                ins.bindString(2, key.substring(sep + 1))
                ins.bindLong(3, n.toLong())
                ins.executeInsert()
            }
            val m = db.compileStatement("INSERT INTO meta(key, value) VALUES(?, ?)")
            for ((k, v) in meta) {
                m.clearBindings()
                m.bindString(1, k)
                m.bindString(2, v)
                m.executeInsert()
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }
}

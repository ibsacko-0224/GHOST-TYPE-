package com.ghosttype.android

import android.content.Context
import android.content.res.Configuration
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.SpannableString
import android.text.Spanned
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

/** Clavier AZERTY dessiné en code (aucune ressource XML) avec une barre de suggestion en haut. */
class KeyboardView(context: Context, private val listener: Listener) : LinearLayout(context) {

    interface Listener {
        fun onText(text: String)
        fun onBackspace()
        fun onEnter()
        fun onAccept()
        fun onDismiss()
    }

    private val dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    private val cBg = if (dark) 0xFF1B1D22.toInt() else 0xFFE9EBF0.toInt()
    private val cKey = if (dark) 0xFF2C2F36.toInt() else 0xFFFFFFFF.toInt()
    private val cSpecial = if (dark) 0xFF3A3E48.toInt() else 0xFFCDD2DC.toInt()
    private val cPressed = if (dark) 0xFF4B5060.toInt() else 0xFFB5BCCB.toInt()
    private val cActive = 0xFF5B3DF5.toInt()
    private val cText = if (dark) 0xFFF1F3F7.toInt() else 0xFF14213D.toInt()
    private val cGhost = if (dark) 0xFF8B93A5.toInt() else 0xFF9AA3B5.toInt()

    private var symbols = false
    private var shift = 0              // 0 = minuscule, 1 = une majuscule, 2 = verrouillé
    private var lastShiftTap = 0L
    private val handler = Handler(Looper.getMainLooper())
    private val ghost = TextView(context)
    private val dismiss = TextView(context)
    private val rows = LinearLayout(context)

    init {
        orientation = VERTICAL
        setBackgroundColor(cBg)
        setPadding(dp(3), dp(2), dp(3), dp(6))
        addView(buildStrip())
        rows.orientation = VERTICAL
        addView(rows, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        rebuild()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ───────── Barre de suggestion
    private fun buildStrip(): View {
        val strip = LinearLayout(context)
        strip.orientation = HORIZONTAL
        strip.gravity = Gravity.CENTER_VERTICAL
        strip.layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(44))

        ghost.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
        ghost.gravity = Gravity.CENTER_VERTICAL
        ghost.setPadding(dp(10), 0, dp(10), 0)
        ghost.maxLines = 1
        ghost.ellipsize = TextUtils.TruncateAt.START
        ghost.setTextColor(cGhost)
        ghost.setOnClickListener { listener.onAccept() }
        strip.addView(ghost, LayoutParams(0, LayoutParams.MATCH_PARENT, 1f))

        dismiss.text = "✕"
        dismiss.gravity = Gravity.CENTER
        dismiss.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        dismiss.setTextColor(cGhost)
        dismiss.visibility = GONE
        dismiss.contentDescription = "Ignorer la suggestion"
        dismiss.setOnClickListener { listener.onDismiss() }
        strip.addView(dismiss, LayoutParams(dp(48), LayoutParams.MATCH_PARENT))
        return strip
    }

    /** Texte déjà tapé en couleur normale, suggestion en gris clair. Appuyer dessus l'accepte. */
    fun showSuggestion(tail: String, suggestion: String) {
        val sp = SpannableString(tail + suggestion)
        if (tail.isNotEmpty()) sp.setSpan(ForegroundColorSpan(cText), 0, tail.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sp.setSpan(ForegroundColorSpan(cGhost), tail.length, sp.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        ghost.text = sp
        ghost.isClickable = true
        dismiss.visibility = VISIBLE
    }

    fun clearSuggestion() {
        ghost.text = ""
        ghost.isClickable = false
        dismiss.visibility = GONE
    }

    fun showNote(note: String) {
        clearSuggestion()
        ghost.text = note
    }

    // ───────── Touches
    private fun keyBg(color: Int): StateListDrawable {
        fun shape(c: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(7).toFloat() }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), shape(cPressed))
            addState(intArrayOf(), shape(color))
        }
    }

    private fun key(label: String, weight: Float, special: Boolean = false, active: Boolean = false, onTap: () -> Unit): TextView {
        val t = TextView(context)
        t.text = label
        t.gravity = Gravity.CENTER
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 19f)
        t.setTextColor(if (active) 0xFFFFFFFF.toInt() else cText)
        t.background = keyBg(if (active) cActive else if (special) cSpecial else cKey)
        val lp = LayoutParams(0, LayoutParams.MATCH_PARENT, weight)
        lp.setMargins(dp(2), dp(3), dp(2), dp(3))
        t.layoutParams = lp
        t.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            onTap()
        }
        return t
    }

    private fun letterKey(c: Char): TextView {
        val label = if (shift > 0) c.uppercaseChar().toString() else c.toString()
        return key(label, 1f) {
            listener.onText(label)
            if (shift == 1) { shift = 0; rebuild() }
        }
    }

    private fun textKey(s: String, weight: Float = 1f) = key(s, weight) { listener.onText(s) }

    private fun shiftKey() = key("⇧", 1.5f, special = true, active = shift > 0) {
        val now = SystemClock.uptimeMillis()
        shift = when {
            shift == 2 -> 0
            shift == 1 && now - lastShiftTap < 350 -> 2
            shift == 1 -> 0
            else -> 1
        }
        lastShiftTap = now
        rebuild()
    }

    private fun backspaceKey(weight: Float): TextView {
        val v = key("⌫", weight, special = true) {}
        val repeat = object : Runnable {
            override fun run() {
                listener.onBackspace()
                handler.postDelayed(this, 60)
            }
        }
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    listener.onBackspace()
                    handler.postDelayed(repeat, 380)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    handler.removeCallbacks(repeat)
                }
            }
            true
        }
        return v
    }

    private fun row(keys: List<View>): LinearLayout {
        val r = LinearLayout(context)
        r.orientation = HORIZONTAL
        keys.forEach { r.addView(it) }
        r.layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(50))
        return r
    }

    private fun rebuild() {
        rows.removeAllViews()
        if (!symbols) {
            rows.addView(row("azertyuiop".map { letterKey(it) }))
            rows.addView(row("qsdfghjklm".map { letterKey(it) }))
            rows.addView(row(listOf<View>(shiftKey()) + "wxcvbn".map { letterKey(it) } + backspaceKey(1.5f)))
            rows.addView(row(listOf(
                key("?123", 1.5f, special = true) { symbols = true; rebuild() },
                textKey(","), textKey("'"),
                key("", 4f) { listener.onText(" ") },
                textKey("."),
                key("⏎", 1.5f, special = true) { listener.onEnter() },
            )))
        } else {
            rows.addView(row("1234567890".map { textKey(it.toString()) }))
            rows.addView(row("@#€_&-+()/".map { textKey(it.toString()) }))
            rows.addView(row("éèêàùçô".map { textKey(it.toString()) } + backspaceKey(1.5f)))
            rows.addView(row(listOf(
                key("ABC", 1.5f, special = true) { symbols = false; rebuild() },
                textKey("!"), textKey("?"),
                key("", 3f) { listener.onText(" ") },
                textKey("."), textKey(","),
                key("⏎", 1.5f, special = true) { listener.onEnter() },
            )))
        }
    }
}

package com.ghosttype.android

import android.content.Context

/** Réglages locaux (SharedPreferences privées). Rien n'est envoyé nulle part. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("ghosttype", Context.MODE_PRIVATE)

    fun enabled(c: Context) = sp(c).getBoolean("enabled", true)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    fun corpus(c: Context): String? = sp(c).getString("corpus", null)
    fun setCorpus(c: Context, v: String) = sp(c).edit().putString("corpus", v).apply()

    fun asked(c: Context) = sp(c).getBoolean("asked", false)
    fun setAsked(c: Context) = sp(c).edit().putBoolean("asked", true).apply()

    fun denylist(c: Context): Set<String> =
        sp(c).getStringSet("denylist", null)?.toSet() ?: Safety.defaultDenylist

    fun setDenylist(c: Context, s: Set<String>) = sp(c).edit().putStringSet("denylist", HashSet(s)).apply()
}

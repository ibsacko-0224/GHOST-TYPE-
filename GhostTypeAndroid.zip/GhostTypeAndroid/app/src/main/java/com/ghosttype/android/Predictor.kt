package com.ghosttype.android

/** Fournisseur n-gramme : mêmes règles que la version macOS (6 mots maximum, repli trigramme → bigramme). */
class Predictor(private val store: NGramStore) {

    fun complete(context: String, isCancelled: () -> Boolean): String? {
        if (!store.isBuilt) return null

        val words = Tokenizer.currentWords(context).toMutableList()
        var partial: String? = null
        if (Tokenizer.endsInsideWord(context) && words.isNotEmpty()) {
            partial = words.removeAt(words.lastIndex)
        }
        val p = partial
        if (words.isEmpty() && (p?.length ?: 0) < 2) return null

        var suffix = ""
        if (p != null) {
            // 1) terminer le mot en cours : trigramme → bigramme → fréquence globale
            var found: String? = null
            if (words.size >= 2) found = store.bestWord(words.takeLast(2).joinToString(" "), p, 1)
            if (found == null && words.isNotEmpty()) found = store.bestWord(words.last(), p, 1)
            if (found == null) found = store.bestWord("", p, 2)
            val w = found ?: return null
            suffix = w.drop(p.length)
            words.add(w)
        }

        // 2) enchaîner les mots suivants, sans jamais dépasser 6 mots au total
        var budget = Suggestion.MAX_WORDS - (if (p == null) 0 else 1)
        val generated = ArrayList<String>()
        val seen = HashSet<String>()
        while (budget > 0 && !isCancelled()) {
            var next: String? = null
            if (words.size >= 2) next = store.bestNext(words.takeLast(2).joinToString(" "), 2)
            if (next == null && words.isNotEmpty()) next = store.bestNext(words.last(), 3)
            val n = next ?: break
            if (!seen.add((words.lastOrNull() ?: "") + "|" + n)) break   // évite les boucles
            generated.add(n)
            words.add(n)
            budget--
        }
        if (isCancelled()) return null

        val spaceFirst = p == null && !context.endsWith(" ") && !context.endsWith("\t")
        val out = StringBuilder(suffix)
        for ((i, w) in generated.withIndex()) {
            if (i == 0 && p == null && !spaceFirst) out.append(w) else out.append(' ').append(w)
        }
        return out.toString().ifEmpty { null }
    }
}

package com.ghosttype.android

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import java.util.concurrent.Executors

/** Écran de réglages : activer le clavier, choisir le dossier de textes, éditer la liste de refus. */
class MainActivity : Activity() {

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var kbStatus: TextView
    private lateinit var corpusInfo: TextView
    private lateinit var denyBox: LinearLayout
    private var building = false

    companion object { private const val REQ_TREE = 42 }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float = 15f, bold: Boolean = false, color: Int = 0xFF14213D.toInt()): TextView =
        TextView(this).apply {
            this.text = text
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun button(text: String, onClick: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            setOnClickListener { onClick() }
        }

    private fun LinearLayout.add(v: View, top: Int = 8): View {
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(top)
        addView(v, lp)
        return v
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(28), dp(20), dp(28))

        root.add(label("GhostType", 28f, true), 0)
        root.add(label("Suggestions de texte en gris pendant que vous tapez. 100 % local : aucune permission réseau, aucune télémétrie.", 14f, color = 0xFF5A6578.toInt()))

        root.add(label("1. Activer le clavier", 17f, true), 24)
        kbStatus = label("", 14f) as TextView
        root.add(kbStatus, 4)
        root.add(button("Ouvrir les réglages des claviers") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) })
        root.add(button("Choisir GhostType comme clavier") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })

        root.add(label("2. Vos textes", 17f, true), 24)
        root.add(label("Dossier contenant vos fichiers .txt et .md (lecture seule, via le sélecteur Android).", 14f, color = 0xFF5A6578.toInt()), 4)
        corpusInfo = label("", 14f) as TextView
        root.add(corpusInfo, 4)
        root.add(button("Choisir le dossier…") { pickFolder() })
        root.add(button("Reconstruire le modèle") { rebuild() })

        root.add(label("3. Réglages", 17f, true), 24)
        val sw = Switch(this)
        sw.text = "Activer les prédictions"
        sw.isChecked = Prefs.enabled(this)
        sw.setOnCheckedChangeListener { _, on -> Prefs.setEnabled(this, on) }
        root.add(sw, 8)

        root.add(label("Applications ignorées", 17f, true), 24)
        root.add(label("Noms de paquets. Les champs de mot de passe, e-mail, URL et le mode privé sont toujours ignorés.", 14f, color = 0xFF5A6578.toInt()), 4)
        denyBox = LinearLayout(this)
        denyBox.orientation = LinearLayout.VERTICAL
        root.add(denyBox, 4)
        val input = EditText(this)
        input.hint = "com.exemple.application"
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        input.setSingleLine()
        root.add(input, 8)
        root.add(button("Ajouter à la liste") {
            val id = input.text.toString().trim()
            if (id.isNotEmpty()) {
                Prefs.setDenylist(this, Prefs.denylist(this) + id)
                input.setText("")
                renderDeny()
            }
        })
        root.add(button("Rétablir la liste par défaut") {
            Prefs.setDenylist(this, Safety.defaultDenylist)
            renderDeny()
        })

        root.add(label("Zone d’essai", 17f, true), 24)
        val test = EditText(this)
        test.hint = "Tapez ici avec le clavier GhostType"
        test.minLines = 2
        test.gravity = Gravity.TOP
        root.add(test, 8)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.WHITE)
        scroll.addView(root)
        setContentView(scroll)
        renderDeny()
    }

    override fun onResume() {
        super.onResume()
        refresh()
        if (Prefs.corpus(this) == null && !Prefs.asked(this)) {
            Prefs.setAsked(this)
            pickFolder()
        }
    }

    private fun refresh() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        val id = ComponentName(this, GhostTypeService::class.java).flattenToShortString()
        val enabled = imm.enabledInputMethodList.any { it.id == id }
        val selected = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) == id
        kbStatus.text = when {
            selected -> "✓ GhostType est votre clavier actuel."
            enabled -> "Activé, mais pas encore sélectionné : touchez « Choisir GhostType »."
            else -> "Pas encore activé : touchez « Ouvrir les réglages » puis activez GhostType."
        }
        if (!building) {
            val store = NGramStore(this)
            corpusInfo.text = if (store.isBuilt) "Modèle prêt : ${store.meta("words")} mots, ${store.meta("files")} fichiers."
            else if (Prefs.corpus(this) == null) "Aucun dossier choisi." else "Modèle non construit."
            store.close()
        }
    }

    private fun renderDeny() {
        denyBox.removeAllViews()
        for (pkg in Prefs.denylist(this).sorted()) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            val name = label(pkg, 13f)
            row.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(button("Retirer") {
                Prefs.setDenylist(this, Prefs.denylist(this) - pkg)
                renderDeny()
            })
            denyBox.addView(row)
        }
    }

    private fun pickFolder() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        startActivityForResult(i, REQ_TREE)
    }

    @Deprecated("API simple suffisante ici")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_TREE || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: SecurityException) { /* le dossier reste lisible pour cette session */ }
        Prefs.setCorpus(this, uri.toString())
        rebuild()
    }

    private fun rebuild() {
        val uriText = Prefs.corpus(this)
        if (uriText == null) { corpusInfo.text = "Choisissez d’abord un dossier."; return }
        if (building) return
        building = true
        corpusInfo.text = "Préparation…"
        val app = applicationContext
        worker.execute {
            val store = NGramStore(app)
            val message = try {
                val s = Corpus.build(app, Uri.parse(uriText), store) { p -> main.post { corpusInfo.text = p } }
                "Modèle prêt : ${s.words} mots, ${s.files} fichiers."
            } catch (e: Exception) {
                "Échec : ${e.message ?: "erreur inconnue"}. Vérifiez que le dossier est toujours accessible."
            } finally {
                store.close()
            }
            main.post { building = false; corpusInfo.text = message }
        }
    }

    override fun onDestroy() {
        worker.shutdown()
        super.onDestroy()
    }
}

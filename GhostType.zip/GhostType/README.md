# GhostType

App de barre de menus macOS qui affiche une **suggestion en gris clair** (6 mots max) à l’endroit du curseur pendant que vous tapez. **Tab** accepte, **Échap** annule. 100 % local : aucun compte, aucune télémétrie, aucun rapport d’incident, aucun appel réseau (sauf, si vous le choisissez, votre serveur d’inférence sur `127.0.0.1`).

Pile : Swift 5.9+, SwiftUI (barre de menus), AppKit (panneau fantôme), un seul projet Xcode, macOS 13+, SQLite système. Aucune dépendance externe.

> ⚠️ Ce projet a été écrit sans pouvoir être compilé (pas de Xcode à disposition). Attendez-vous à corriger quelques erreurs de compilation au premier build.

## Installer et lancer

**Depuis Xcode** : ouvrez `GhostType.xcodeproj` → cible *GhostType* → *Signing & Capabilities* → choisissez votre équipe (ou *Sign to Run Locally*) → ▶︎ Run.

**Depuis GitHub Actions** : onglet *Actions* → *Build GhostType (macOS)* → *Run workflow*. Récupérez `GhostType-macOS.zip` dans *Releases*. L’app n’est pas signée : dézippez, puis soit clic droit sur GhostType.app → *Ouvrir* → *Ouvrir*, soit dans le Terminal :
```
xattr -dr com.apple.quarantine GhostType.app
```
Mettez ensuite GhostType.app dans `/Applications`.

Au premier lancement, GhostType vous demande le **dossier de vos fichiers .txt et .md** : il construit le modèle n-gramme dans `~/Library/Application Support/GhostType/ngram.sqlite`. Menu → *Reconstruire* pour le refaire après avoir changé vos textes.

## Autorisations à accorder (exactement)

GhostType a besoin de **deux** autorisations. Il ne tourne pas dans le sandbox (le sandbox interdit l’accessibilité et les CGEventTap).

1. **Réglages Système → Confidentialité et sécurité → Accessibilité**
   - Cliquez sur **+** (déverrouillez avec Touch ID / mot de passe si demandé), choisissez **GhostType.app**, puis mettez l’interrupteur **GhostType** sur **activé**.
   - Sert à lire le texte et la position du curseur du champ actif (AXUIElement) et à intercepter Tab / Échap.
2. **Réglages Système → Confidentialité et sécurité → Surveillance de l’entrée** (*Input Monitoring*)
   - Même geste : **+** → **GhostType.app** → interrupteur **activé**.
   - Sert à observer les touches pressées (CGEventTap).
3. **Quittez puis relancez GhostType.** Le tap clavier ne démarre souvent qu’après un redémarrage de l’app.

Raccourcis : le menu GhostType contient *Demander*, *Ouvrir Accessibilité* et *Ouvrir Entrée*. Deux coches vertes = prêt. Sur un macOS en anglais : *Privacy & Security → Accessibility* et *Input Monitoring*.

Si vous recompilez ou remplacez l’app, macOS peut oublier les autorisations (signature ad hoc) : retirez GhostType de la liste avec **−** puis ajoutez-le à nouveau.

## Sécurité (non négociable)

GhostType **ne lit rien et ne prédit rien** quand :
- la **saisie sécurisée** (*Secure Event Input*) est active (champs de mot de passe, « Secure Keyboard Entry » du Terminal…) ;
- le rôle ou sous-rôle de l’élément est `AXSecureTextField` ;
- l’application du champ ou celle au premier plan figure dans la **liste de refus** (menu → *Liste de refus…*, modifiable ; par défaut : gestionnaires de mots de passe) ;
- l’application est un navigateur, une app Electron/Chromium ou un terminal (liste fixe, détection dans le bundle).

Il ne **modifie jamais** le texte de l’app cible tant que vous n’avez pas appuyé sur Tab. La suggestion est insérée par des événements clavier synthétiques. Désactiver le bouton du menu arrête complètement le tap clavier.

## Moteurs de prédiction

- **A · N-gramme (défaut)** : trigrammes/bigrammes/mots construits depuis votre dossier, stockés en SQLite. Minuscules uniquement, pas d’optimisation multilingue.
- **B · Serveur local** : llama.cpp (`/completion`) ou MLX (`/v1/completions`). Copiez `.env.example` vers `~/Library/Application Support/GhostType/.env` et ajustez `GHOSTTYPE_LLM_URL`. Jetons limités (≤ 16), expiration **250 ms** maximum, requête **annulée à la frappe suivante**. Les hôtes autres que `127.0.0.1`, `localhost` et `::1` sont refusés.

Délai de 120 ms après la dernière frappe avant toute prédiction. La suggestion n’apparaît que si le curseur est en fin de ligne et sans sélection.

## Pourquoi ça ne marche pas dans Chrome et VS Code

Explication simple : GhostType lit le champ actif via l’API d’accessibilité de macOS. Ça marche quand le champ est un vrai champ de texte macOS (AppKit) qui expose son texte, la position du curseur et un rectangle pour chaque caractère.

- **Chrome (et Edge, Brave, Safari, Firefox…)** : les champs d’une page web ne sont pas des champs macOS, ils sont dessinés par le moteur du navigateur. Le navigateur ne construit son arbre d’accessibilité que s’il pense qu’un lecteur d’écran est actif ; sinon le champ n’expose ni texte ni position utilisable. Même quand il l’expose, les positions de caractères sont souvent approximatives ou absentes, les éditeurs riches (contenteditable) rapportent des plages étranges, et la touche Tab sert déjà à la page (navigation, raccourcis) : l’avaler casserait des sites.
- **VS Code (et toute app Electron)** : même cause, car Electron embarque Chromium. En plus, l’éditeur Monaco ne met pas votre document dans un champ de texte : il l’affiche ligne par ligne et reçoit les frappes dans une minuscule zone de saisie cachée. La valeur lue par l’accessibilité n’est donc pas votre texte, et la position du curseur ne correspond à rien d’utilisable. Tab y est aussi pris par l’éditeur (indentation, suggestions).

Plutôt que de deviner, GhostType **détecte** ces contextes (liste d’applications connues, présence d’Electron/Chromium dans le bundle, attributs DOM sur le champ) et **ne fait rien**. Le menu indique la raison (« Application non prise en charge »). Les terminaux sont exclus pour la même raison de fond : pas de champ de texte natif.

## Structure

```
GhostType/UI/          Barre de menus, éditeur de liste de refus, état
GhostType/System/      CGEventTap, lecture AX, panneau fantôme, insertion, sécurité, .env
GhostType/Prediction/  Protocole, fournisseur A (n-grammes + SQLite), fournisseur B (serveur local)
```

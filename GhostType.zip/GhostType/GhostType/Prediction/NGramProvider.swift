import Foundation
import SQLite3

struct CorpusStats: Sendable {
    var files: Int
    var words: Int
    var entries: Int
    var builtAt: Date
}

/// Magasin de n-grammes (ordre 1 à 3) dans un fichier SQLite.
/// `ctx` = 0, 1 ou 2 mots précédents séparés par une espace ; `next` = mot suivant.
final class NGramStore {
    private let db: SQLiteDB
    private lazy var nextStmt: OpaquePointer? = try? db.prepare(
        "SELECT next FROM ngram WHERE ctx = ?1 AND count >= ?2 ORDER BY count DESC LIMIT 1")
    private lazy var wordStmt: OpaquePointer? = try? db.prepare(
        "SELECT next FROM ngram WHERE ctx = ?1 AND next > ?2 AND next < ?3 AND count >= ?4 ORDER BY count DESC LIMIT 1")

    init(path: String) throws {
        db = try SQLiteDB(path: path)
        try db.exec("PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL;")
        try db.exec("""
        CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS ngram(
            ctx TEXT NOT NULL, next TEXT NOT NULL, count INTEGER NOT NULL,
            PRIMARY KEY(ctx, next)) WITHOUT ROWID;
        CREATE INDEX IF NOT EXISTS ngram_ctx_count ON ngram(ctx, count DESC);
        """)
    }

    func meta(_ key: String) -> String? {
        guard let s = try? db.prepare("SELECT value FROM meta WHERE key = ?1") else { return nil }
        defer { sqlite3_finalize(s) }
        db.bind(s, 1, key)
        guard sqlite3_step(s) == SQLITE_ROW, let c = sqlite3_column_text(s, 0) else { return nil }
        return String(cString: c)
    }

    var isBuilt: Bool { meta("built_at") != nil }

    func bestNext(ctx: String, minCount: Int) -> String? {
        guard let s = nextStmt else { return nil }
        sqlite3_reset(s); sqlite3_clear_bindings(s)
        db.bind(s, 1, ctx); db.bind(s, 2, minCount)
        guard sqlite3_step(s) == SQLITE_ROW, let c = sqlite3_column_text(s, 0) else { return nil }
        return String(cString: c)
    }

    /// Mot le plus fréquent qui commence par `prefix` et est strictement plus long.
    func bestWord(ctx: String, prefix: String, minCount: Int) -> String? {
        guard let s = wordStmt else { return nil }
        sqlite3_reset(s); sqlite3_clear_bindings(s)
        db.bind(s, 1, ctx); db.bind(s, 2, prefix); db.bind(s, 3, prefix + "\u{10FFFF}"); db.bind(s, 4, minCount)
        guard sqlite3_step(s) == SQLITE_ROW, let c = sqlite3_column_text(s, 0) else { return nil }
        return String(cString: c)
    }

    func replaceAll(counts: [String: Int], meta: [String: String]) throws {
        try db.exec("BEGIN IMMEDIATE")
        do {
            try db.exec("DELETE FROM ngram; DELETE FROM meta;")
            let ins = try db.prepare("INSERT INTO ngram(ctx, next, count) VALUES(?1, ?2, ?3)")
            defer { sqlite3_finalize(ins) }
            for (key, n) in counts {
                guard let sep = key.firstIndex(of: "\u{1F}") else { continue }
                sqlite3_reset(ins); sqlite3_clear_bindings(ins)
                db.bind(ins, 1, String(key[..<sep]))
                db.bind(ins, 2, String(key[key.index(after: sep)...]))
                db.bind(ins, 3, n)
                if sqlite3_step(ins) != SQLITE_DONE { throw SQLiteError.step(db.lastError) }
            }
            let m = try db.prepare("INSERT INTO meta(key, value) VALUES(?1, ?2)")
            defer { sqlite3_finalize(m) }
            for (k, v) in meta {
                sqlite3_reset(m); sqlite3_clear_bindings(m)
                db.bind(m, 1, k); db.bind(m, 2, v)
                if sqlite3_step(m) != SQLITE_DONE { throw SQLiteError.step(db.lastError) }
            }
            try db.exec("COMMIT")
        } catch {
            try? db.exec("ROLLBACK")
            throw error
        }
    }
}

/// Fournisseur A (par défaut) : n-grammes construits depuis vos .txt / .md, 100 % local.
actor NGramProvider: PredictionProvider {
    nonisolated let name = "N-gramme local"
    private let path: URL
    private var store: NGramStore?

    static let maxFileBytes = 5 * 1024 * 1024
    static let maxTotalBytes = 60 * 1024 * 1024

    init(databaseURL: URL) { self.path = databaseURL }

    private func openStore() throws -> NGramStore {
        if let store { return store }
        try FileManager.default.createDirectory(at: path.deletingLastPathComponent(), withIntermediateDirectories: true)
        let s = try NGramStore(path: path.path)
        store = s
        return s
    }

    func summary() -> String? {
        guard let s = try? openStore(), s.isBuilt else { return nil }
        let words = s.meta("words") ?? "?"
        let files = s.meta("files") ?? "?"
        return "\(words) mots · \(files) fichiers"
    }

    func isBuilt() -> Bool { (try? openStore())?.isBuilt ?? false }

    // MARK: Construction à partir du dossier de corpus

    private static func listFiles(in folder: URL) -> [URL] {
        guard let en = FileManager.default.enumerator(
            at: folder, includingPropertiesForKeys: [.isRegularFileKey],
            options: [.skipsHiddenFiles, .skipsPackageDescendants]) else { return [] }
        var out: [URL] = []
        while let u = en.nextObject() as? URL {
            if ["txt", "md"].contains(u.pathExtension.lowercased()) { out.append(u) }
        }
        return out.sorted { $0.path < $1.path }
    }

    func rebuild(from folder: URL, progress: @Sendable (String) -> Void) throws -> CorpusStats {
        let store = try openStore()
        let files = Self.listFiles(in: folder)
        var counts: [String: Int] = [:]
        var totalBytes = 0, usedFiles = 0, words = 0

        for (i, url) in files.enumerated() {
            try Task.checkCancellation()
            progress("Lecture \(i + 1)/\(files.count)…")
            guard let data = try? Data(contentsOf: url), data.count <= Self.maxFileBytes,
                  totalBytes + data.count <= Self.maxTotalBytes,
                  let text = String(data: data, encoding: .utf8) else { continue }
            totalBytes += data.count
            usedFiles += 1
            for seg in Tokenizer.segments(text) {
                for j in seg.indices {
                    words += 1
                    let next = seg[j]
                    counts["\u{1F}" + next, default: 0] += 1
                    if j >= 1 { counts[seg[j - 1] + "\u{1F}" + next, default: 0] += 1 }
                    if j >= 2 { counts[seg[j - 2] + " " + seg[j - 1] + "\u{1F}" + next, default: 0] += 1 }
                }
            }
        }
        progress("Écriture de \(counts.count) entrées…")
        let now = Date()
        try store.replaceAll(counts: counts, meta: [
            "built_at": ISO8601DateFormatter().string(from: now),
            "corpus": folder.path, "files": String(usedFiles), "words": String(words),
        ])
        return CorpusStats(files: usedFiles, words: words, entries: counts.count, builtAt: now)
    }

    // MARK: Prédiction

    func complete(context: String) async throws -> String? {
        let store = try openStore()
        guard store.isBuilt else { return nil }

        var words = Tokenizer.currentWords(before: context)
        var partial: String?
        if Tokenizer.endsInsideWord(context), let last = words.last {
            partial = last
            words.removeLast()
        }
        guard !words.isEmpty || (partial?.count ?? 0) >= 2 else { return nil }

        var generated: [String] = []
        var suffix = ""

        if let p = partial {
            // 1) terminer le mot en cours : trigramme → bigramme → fréquence globale
            var found: String?
            if words.count >= 2 { found = store.bestWord(ctx: words.suffix(2).joined(separator: " "), prefix: p, minCount: 1) }
            if found == nil, let w = words.last { found = store.bestWord(ctx: w, prefix: p, minCount: 1) }
            if found == nil { found = store.bestWord(ctx: "", prefix: p, minCount: 2) }
            guard let w = found else { return nil }
            suffix = String(w.dropFirst(p.count))
            words.append(w)
        }

        // 2) enchaîner les mots suivants (repli trigramme → bigramme), 6 mots au plus
        var budget = Suggestion.maxWords - (partial == nil ? 0 : 1)
        var seen = Set<String>()
        while budget > 0 {
            try Task.checkCancellation()
            var next: String?
            if words.count >= 2 { next = store.bestNext(ctx: words.suffix(2).joined(separator: " "), minCount: 2) }
            if next == nil, let w = words.last { next = store.bestNext(ctx: w, minCount: 3) }
            guard let n = next else { break }
            let key = (words.last ?? "") + "|" + n
            guard seen.insert(key).inserted else { break }   // évite les boucles
            generated.append(n)
            words.append(n)
            budget -= 1
        }

        let spaceFirst = partial == nil && !context.hasSuffix(" ") && !context.hasSuffix("\t")
        var out = suffix
        for (i, w) in generated.enumerated() {
            out += (i == 0 && !spaceFirst && partial == nil) ? w : " " + w
        }
        return out.isEmpty ? nil : out
    }
}

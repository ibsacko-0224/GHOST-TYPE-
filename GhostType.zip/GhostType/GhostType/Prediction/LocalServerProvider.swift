import Foundation

/// Exécute `op` avec une échéance stricte ; annule l'opération au-delà.
func withDeadline<T: Sendable>(_ seconds: TimeInterval, _ op: @escaping @Sendable () async throws -> T) async throws -> T {
    try await withThrowingTaskGroup(of: T.self) { group in
        group.addTask { try await op() }
        group.addTask {
            try await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
            throw URLError(.timedOut)
        }
        defer { group.cancelAll() }
        guard let first = try await group.next() else { throw URLError(.cancelled) }
        return first
    }
}

/// Fournisseur B : serveur llama.cpp (`/completion`) ou MLX (`/v1/completions`) sur la machine locale.
/// Jetons limités, échéance de 250 ms, requête annulée dès la frappe suivante.
struct LocalServerProvider: PredictionProvider {
    let name = "Serveur local"
    let endpoint: URL
    let maxTokens: Int
    let deadline: TimeInterval
    private let session: URLSession

    init(endpoint: URL, maxTokens: Int, deadlineMs: Int) {
        self.endpoint = endpoint
        self.maxTokens = maxTokens
        self.deadline = Double(deadlineMs) / 1000
        let cfg = URLSessionConfiguration.ephemeral          // ni cache, ni cookies, ni stockage
        cfg.requestCachePolicy = .reloadIgnoringLocalCacheData
        cfg.waitsForConnectivity = false
        cfg.timeoutIntervalForRequest = Double(deadlineMs) / 1000
        cfg.timeoutIntervalForResource = Double(deadlineMs) / 1000
        cfg.httpShouldSetCookies = false
        cfg.connectionProxyDictionary = [:]                  // jamais de proxy : on parle à localhost
        session = URLSession(configuration: cfg)
    }

    func complete(context: String) async throws -> String? {
        var req = URLRequest(url: endpoint)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let body: [String: Any] = [
            "prompt": context,
            "n_predict": maxTokens, "max_tokens": maxTokens,   // llama.cpp / MLX (OpenAI-compatible)
            "temperature": 0.2, "top_k": 20,
            "stop": ["\n"], "stream": false, "cache_prompt": true,
        ]
        req.httpBody = try JSONSerialization.data(withJSONObject: body)
        let request = req
        let session = self.session
        let (data, response) = try await withDeadline(deadline) { try await session.data(for: request) }
        guard (response as? HTTPURLResponse)?.statusCode == 200 else { return nil }
        guard let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any] else { return nil }
        if let t = obj["content"] as? String { return t }
        if let choices = obj["choices"] as? [[String: Any]], let t = choices.first?["text"] as? String { return t }
        return nil
    }
}

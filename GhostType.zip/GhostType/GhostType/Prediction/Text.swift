import Foundation

/// Découpage en mots/phrases et nettoyage des suggestions. Logique pure, sans dépendance système.
enum Tokenizer {
    static let boundaries: Set<Character> = [".", "!", "?", "\n", "\r", ";", ":", "…"]

    static func isWordChar(_ c: Character) -> Bool {
        c.isLetter || c.isNumber || c == "'" || c == "’" || c == "-"
    }

    /// Phrases → mots en minuscules (les frontières de phrase ne sont jamais franchies).
    static func segments(_ text: String) -> [[String]] {
        var result: [[String]] = []
        var seg: [String] = []
        var cur = ""
        let trim = CharacterSet(charactersIn: "-'’")
        func flushWord() {
            let w = cur.trimmingCharacters(in: trim)
            if !w.isEmpty, w.contains(where: { $0.isLetter || $0.isNumber }) { seg.append(w.lowercased()) }
            cur = ""
        }
        func flushSegment() {
            flushWord()
            if !seg.isEmpty { result.append(seg); seg = [] }
        }
        for ch in text {
            if isWordChar(ch) { cur.append(ch) }
            else if boundaries.contains(ch) { flushSegment() }
            else { flushWord() }
        }
        flushSegment()
        return result
    }

    /// Mots de la phrase en cours, juste avant le curseur ([] si le texte se termine par une frontière de phrase).
    static func currentWords(before context: String) -> [String] {
        var idx = context.endIndex
        while idx > context.startIndex {
            let prev = context.index(before: idx)
            let c = context[prev]
            if c == " " || c == "\t" { idx = prev; continue }
            if boundaries.contains(c) { return [] }
            break
        }
        return segments(context).last ?? []
    }

    /// Vrai si le curseur est au milieu d'un mot (dernier caractère = caractère de mot).
    static func endsInsideWord(_ context: String) -> Bool {
        guard let last = context.last else { return false }
        return isWordChar(last)
    }
}

enum Suggestion {
    static let maxWords = 6

    /// Une seule ligne, 6 mots maximum, sans espace superflu. nil si rien d'exploitable.
    static func clean(_ raw: String, context: String) -> String? {
        var s = raw.replacingOccurrences(of: "\r", with: "")
        if let nl = s.firstIndex(of: "\n") { s = String(s[..<nl]) }
        let lead = String(s.prefix(while: { $0 == " " || $0 == "\t" }))
        let words = s.split(whereSeparator: { $0 == " " || $0 == "\t" }).prefix(maxWords)
        guard !words.isEmpty else { return nil }
        var out = lead.isEmpty ? "" : " "
        out += words.joined(separator: " ")
        if context.last == " " || context.last == "\t", out.hasPrefix(" ") { out.removeFirst() }
        return out.isEmpty ? nil : out
    }
}

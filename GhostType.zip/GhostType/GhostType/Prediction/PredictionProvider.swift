import Foundation

/// Deux moteurs interchangeables. `complete` doit honorer l'annulation de la tâche appelante.
protocol PredictionProvider: Sendable {
    var name: String { get }
    /// `context` : au plus 200 caractères avant le curseur. Retourne la suite brute (≤ 6 mots après nettoyage).
    func complete(context: String) async throws -> String?
}

enum ProviderKind: String, CaseIterable, Identifiable {
    case ngram, localServer
    var id: String { rawValue }
    var label: String {
        switch self {
        case .ngram: return "A · N-gramme sur l’appareil"
        case .localServer: return "B · Serveur local (llama.cpp / MLX)"
        }
    }
}

import AppKit
import ApplicationServices
import SwiftUI

@MainActor
final class AppModel: ObservableObject {
    static let shared = AppModel()
    private let defaults = UserDefaults.standard

    @Published var enabled: Bool { didSet { defaults.set(enabled, forKey: "enabled"); engine?.sync() } }
    @Published var providerKind: ProviderKind {
        didSet { defaults.set(providerKind.rawValue, forKey: "provider"); engine?.reloadServer() }
    }
    @Published var denylist: [String] { didSet { defaults.set(denylist, forKey: "denylist") } }
    @Published var corpusPath: String? { didSet { defaults.set(corpusPath, forKey: "corpusPath") } }

    @Published var accessibilityGranted = false
    @Published var inputMonitoringGranted = false
    @Published var tapRunning = false
    @Published var corpusBusy = false
    @Published var corpusStatus = ""
    @Published var envMessage = ""
    @Published var lastSkip = ""
    @Published var lastExternalApp: (id: String, name: String)?

    private(set) var engine: PredictionEngine?
    private var timer: Timer?

    private init() {
        enabled = defaults.object(forKey: "enabled") as? Bool ?? true
        providerKind = ProviderKind(rawValue: defaults.string(forKey: "provider") ?? "") ?? .ngram
        denylist = defaults.stringArray(forKey: "denylist") ?? Safety.defaultDenylist
        corpusPath = defaults.string(forKey: "corpusPath")
    }

    static var databaseURL: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("GhostType/ngram.sqlite")
    }

    func start() {
        guard engine == nil else { return }
        engine = PredictionEngine(model: self, ngram: NGramProvider(databaseURL: Self.databaseURL))
        NSWorkspace.shared.notificationCenter.addObserver(
            forName: NSWorkspace.didActivateApplicationNotification, object: nil, queue: .main) { [weak self] note in
            guard let app = note.userInfo?[NSWorkspace.applicationUserInfoKey] as? NSRunningApplication,
                  let id = app.bundleIdentifier, id != Bundle.main.bundleIdentifier else { return }
            let name = app.localizedName ?? id
            Task { @MainActor in self?.lastExternalApp = (id, name) }
        }
        refreshStatus()
        timer = Timer.scheduledTimer(withTimeInterval: 2, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.refreshStatus() }
        }
        Task { await refreshCorpusSummary(); promptForCorpusIfNeeded() }
    }

    // MARK: Autorisations

    func refreshStatus() {
        accessibilityGranted = AXIsProcessTrusted()
        inputMonitoringGranted = CGPreflightListenEventAccess()
        engine?.sync()
        tapRunning = engine?.tapRunning ?? false
    }

    func requestPermissions() {
        let key = kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String
        _ = AXIsProcessTrustedWithOptions([key: true] as CFDictionary)
        _ = CGRequestListenEventAccess()
    }

    func openPrivacyPane(_ pane: String) {
        if let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?\(pane)") {
            NSWorkspace.shared.open(url)
        }
    }

    // MARK: Liste de refus et règles de sécurité

    func skipReason(forBundle id: String?) -> SkipReason? {
        guard let id else { return nil }
        if id == Bundle.main.bundleIdentifier { return .ownApp }
        if denylist.contains(id) { return .deniedApp }
        if Safety.isUnsupportedApp(bundleID: id) { return .unsupportedApp }
        return nil
    }

    func note(_ reason: SkipReason?) { lastSkip = reason?.label ?? "" }

    func addToDenylist(_ id: String) {
        let clean = id.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty, !denylist.contains(clean) else { return }
        denylist.append(clean)
        denylist.sort()
    }

    func removeFromDenylist(_ id: String) { denylist.removeAll { $0 == id } }

    // MARK: Corpus

    func chooseCorpusFolder() {
        NSApp.activate(ignoringOtherApps: true)
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        panel.prompt = "Utiliser ce dossier"
        panel.message = "Choisissez le dossier contenant vos fichiers .txt et .md"
        panel.begin { [weak self] response in
            guard response == .OK, let url = panel.url else { return }
            Task { @MainActor in
                self?.corpusPath = url.path
                self?.rebuildCorpus()
            }
        }
    }

    func promptForCorpusIfNeeded() {
        guard corpusPath == nil else { return }
        chooseCorpusFolder()           // premier lancement : on demande le dossier de corpus
    }

    func refreshCorpusSummary() async {
        if let engine, let s = await engine.ngram.summary() { corpusStatus = s }
        else if corpusPath == nil { corpusStatus = "Aucun corpus : choisissez un dossier" }
    }

    func rebuildCorpus() {
        guard let engine, let path = corpusPath, !corpusBusy else { return }
        corpusBusy = true
        corpusStatus = "Préparation…"
        Task {
            do {
                let stats = try await engine.ngram.rebuild(from: URL(fileURLWithPath: path, isDirectory: true)) { msg in
                    Task { @MainActor in AppModel.shared.corpusStatus = msg }
                }
                corpusStatus = "\(stats.words) mots · \(stats.files) fichiers"
            } catch {
                corpusStatus = "Échec : \(error.localizedDescription)"
            }
            corpusBusy = false
        }
    }
}

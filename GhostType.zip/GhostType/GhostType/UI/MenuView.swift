import SwiftUI

struct MenuView: View {
    @ObservedObject var model: AppModel
    @Environment(\.openWindow) private var openWindow

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Toggle("Activer GhostType", isOn: $model.enabled)
                .toggleStyle(.switch)
                .font(.headline)

            permissions

            Divider()

            Picker("Moteur", selection: $model.providerKind) {
                ForEach(ProviderKind.allCases) { Text($0.label).tag($0) }
            }
            .pickerStyle(.radioGroup)

            if model.providerKind == .ngram { corpus } else { server }

            Divider()

            if !model.lastSkip.isEmpty {
                Text(model.lastSkip).font(.caption).foregroundStyle(.secondary)
            }
            HStack {
                Button("Liste de refus…") {
                    openWindow(id: "denylist")
                    NSApp.activate(ignoringOtherApps: true)
                }
                Spacer()
                Button("Quitter") { NSApplication.shared.terminate(nil) }
            }
        }
        .padding(14)
        .frame(width: 340)
    }

    private var permissions: some View {
        VStack(alignment: .leading, spacing: 6) {
            row("Accessibilité", model.accessibilityGranted)
            row("Surveillance de l’entrée", model.inputMonitoringGranted)
            if !(model.accessibilityGranted && model.inputMonitoringGranted) {
                HStack {
                    Button("Demander") { model.requestPermissions() }
                    Button("Ouvrir Accessibilité") { model.openPrivacyPane("Privacy_Accessibility") }
                    Button("Ouvrir Entrée") { model.openPrivacyPane("Privacy_ListenEvent") }
                }
                .font(.caption)
                Text("Après autorisation, quittez puis relancez GhostType.")
                    .font(.caption).foregroundStyle(.secondary)
            } else if model.enabled && !model.tapRunning {
                Text("Le suivi du clavier ne démarre pas : relancez GhostType.")
                    .font(.caption).foregroundStyle(.orange)
            }
        }
    }

    private func row(_ title: String, _ ok: Bool) -> some View {
        Label(title, systemImage: ok ? "checkmark.circle.fill" : "xmark.circle.fill")
            .foregroundStyle(ok ? Color.green : Color.red)
            .font(.callout)
    }

    private var corpus: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(model.corpusPath ?? "Aucun dossier de corpus")
                .font(.caption).lineLimit(2).truncationMode(.middle)
            HStack {
                Button("Choisir le dossier…") { model.chooseCorpusFolder() }
                Button("Reconstruire") { model.rebuildCorpus() }
                    .disabled(model.corpusPath == nil || model.corpusBusy)
                if model.corpusBusy { ProgressView().controlSize(.small) }
            }
            if !model.corpusStatus.isEmpty { Text(model.corpusStatus).font(.caption).foregroundStyle(.secondary) }
        }
    }

    private var server: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(model.envMessage).font(.caption).foregroundStyle(.secondary)
            Button("Relire .env") { model.engine?.reloadServer() }.font(.caption)
        }
    }
}

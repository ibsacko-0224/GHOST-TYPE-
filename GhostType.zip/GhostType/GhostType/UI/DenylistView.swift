import SwiftUI
import UniformTypeIdentifiers

/// Éditeur de la liste de refus : GhostType ne lit ni ne prédit jamais dans ces applications.
struct DenylistView: View {
    @ObservedObject var model: AppModel
    @State private var newID = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Applications ignorées").font(.headline)
            Text("Identifiants de bundle. Les navigateurs, applications Electron et terminaux sont toujours ignorés (non modifiable).")
                .font(.caption).foregroundStyle(.secondary)

            List {
                ForEach(model.denylist, id: \.self) { id in
                    HStack {
                        Text(id).font(.system(.body, design: .monospaced))
                        Spacer()
                        Button(role: .destructive) { model.removeFromDenylist(id) } label: { Image(systemName: "trash") }
                            .buttonStyle(.borderless)
                    }
                }
            }
            .frame(minHeight: 180)

            HStack {
                TextField("com.exemple.application", text: $newID)
                    .textFieldStyle(.roundedBorder)
                    .onSubmit(add)
                Button("Ajouter", action: add).disabled(newID.trimmingCharacters(in: .whitespaces).isEmpty)
            }
            HStack {
                if let app = model.lastExternalApp {
                    Button("Ajouter « \(app.name) »") { model.addToDenylist(app.id) }
                }
                Button("Choisir une application…", action: pickApp)
                Spacer()
                Button("Rétablir la liste par défaut") { model.denylist = Safety.defaultDenylist }
            }
            .font(.callout)
        }
        .padding(16)
        .frame(width: 520)
    }

    private func add() {
        model.addToDenylist(newID)
        newID = ""
    }

    private func pickApp() {
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.application]
        panel.directoryURL = URL(fileURLWithPath: "/Applications")
        panel.canChooseDirectories = false
        if panel.runModal() == .OK, let url = panel.url, let id = Bundle(url: url)?.bundleIdentifier {
            model.addToDenylist(id)
        }
    }
}

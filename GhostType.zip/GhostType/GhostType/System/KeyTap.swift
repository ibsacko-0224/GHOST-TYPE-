import AppKit
import CoreGraphics

enum KeyCode {
    static let tab: Int64 = 48
    static let escape: Int64 = 53
}

/// Marque posée sur nos propres événements synthétiques pour ne jamais les retraiter.
let ghostSyntheticMarker: Int64 = 0x4748_5354

/// État lu par le tap pour décider, de façon synchrone, s'il avale Tab / Échap. Écrit et lu sur le thread principal.
final class TapGate: @unchecked Sendable {
    var suggestionVisible = false
    var insertingUntil: CFAbsoluteTime = 0
}

/// CGEventTap actif sur les keyDown : observe la saisie, intercepte Tab (accepter) et Échap (annuler)
/// uniquement quand une suggestion est affichée. Tourne sur la boucle principale.
final class KeyTap {
    var onKey: (@Sendable () -> Void)?
    var onTab: (@Sendable () -> Void)?
    var onEscape: (@Sendable () -> Void)?
    let gate: TapGate
    private var tap: CFMachPort?
    private var source: CFRunLoopSource?

    init(gate: TapGate) { self.gate = gate }

    var isRunning: Bool { tap != nil }

    @discardableResult
    func start() -> Bool {
        if tap != nil { return true }
        let mask = CGEventMask(1) << CGEventType.keyDown.rawValue
        let me = Unmanaged.passUnretained(self).toOpaque()
        guard let t = CGEvent.tapCreate(tap: .cgSessionEventTap, place: .headInsertEventTap, options: .defaultTap,
                                        eventsOfInterest: mask, callback: ghostTapCallback, userInfo: me) else { return false }
        tap = t
        source = CFMachPortCreateRunLoopSource(kCFAllocatorDefault, t, 0)
        CFRunLoopAddSource(CFRunLoopGetMain(), source, .commonModes)
        CGEvent.tapEnable(tap: t, enable: true)
        return true
    }

    func stop() {
        if let source { CFRunLoopRemoveSource(CFRunLoopGetMain(), source, .commonModes) }
        if let tap { CGEvent.tapEnable(tap: tap, enable: false); CFMachPortInvalidate(tap) }
        tap = nil
        source = nil
    }

    fileprivate func handle(type: CGEventType, event: CGEvent) -> Unmanaged<CGEvent>? {
        let pass = Unmanaged.passUnretained(event)
        switch type {
        case .tapDisabledByTimeout, .tapDisabledByUserInput:
            if let tap { CGEvent.tapEnable(tap: tap, enable: true) }
            return pass
        case .keyDown:
            if event.getIntegerValueField(.eventSourceUserData) == ghostSyntheticMarker { return pass }
            if CFAbsoluteTimeGetCurrent() < gate.insertingUntil { return pass }
            let code = event.getIntegerValueField(.keyboardEventKeycode)
            let modifiers: CGEventFlags = [.maskCommand, .maskControl, .maskAlternate, .maskShift]
            let plain = event.flags.intersection(modifiers).isEmpty
            if plain && gate.suggestionVisible {
                if code == KeyCode.tab { onTab?(); return nil }
                if code == KeyCode.escape { onEscape?(); return nil }
            }
            onKey?()
            return pass
        default:
            return pass
        }
    }
}

private func ghostTapCallback(proxy: CGEventTapProxy, type: CGEventType, event: CGEvent,
                              userInfo: UnsafeMutableRawPointer?) -> Unmanaged<CGEvent>? {
    guard let userInfo else { return Unmanaged.passUnretained(event) }
    return Unmanaged<KeyTap>.fromOpaque(userInfo).takeUnretainedValue().handle(type: type, event: event)
}

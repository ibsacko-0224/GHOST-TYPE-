import CoreGraphics

/// Insère le texte accepté en envoyant des événements clavier synthétiques (jamais d'écriture via l'accessibilité).
enum TextInserter {
    static func insert(_ text: String) {
        guard let source = CGEventSource(stateID: .privateState) else { return }
        let units = Array(text.utf16)
        var i = 0
        while i < units.count {
            var end = min(i + 16, units.count)
            if end < units.count, UTF16.isLeadSurrogate(units[end - 1]) { end -= 1 }   // ne pas couper une paire
            if end <= i { end = min(i + 2, units.count) }
            post(Array(units[i..<end]), source)
            i = end
        }
    }

    private static func post(_ chunk: [UniChar], _ source: CGEventSource) {
        for down in [true, false] {
            guard let e = CGEvent(keyboardEventSource: source, virtualKey: 0, keyDown: down) else { continue }
            e.flags = []
            e.keyboardSetUnicodeString(stringLength: chunk.count, unicodeString: chunk)
            e.setIntegerValueField(.eventSourceUserData, value: ghostSyntheticMarker)
            e.post(tap: .cghidEventTap)
        }
    }
}

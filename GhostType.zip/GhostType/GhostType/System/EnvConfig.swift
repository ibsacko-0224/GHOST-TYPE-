import Foundation

/// Configuration du fournisseur B, lue dans `.env` (jamais dans le code, jamais commitée).
/// Ordre : variables d'environnement du processus, puis ~/Library/Application Support/GhostType/.env
struct EnvConfig {
    var values: [String: String]

    static var envFileURL: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        return base.appendingPathComponent("GhostType/.env")
    }

    static func parse(_ text: String) -> [String: String] {
        var out: [String: String] = [:]
        for raw in text.split(whereSeparator: \.isNewline) {
            var line = raw.trimmingCharacters(in: .whitespaces)
            if line.isEmpty || line.hasPrefix("#") { continue }
            if line.hasPrefix("export ") { line = String(line.dropFirst(7)) }
            guard let eq = line.firstIndex(of: "=") else { continue }
            let key = line[..<eq].trimmingCharacters(in: .whitespaces)
            var value = line[line.index(after: eq)...].trimmingCharacters(in: .whitespaces)
            if value.count >= 2, let f = value.first, f == value.last, f == "\"" || f == "'" { value = String(value.dropFirst().dropLast()) }
            if !key.isEmpty { out[key] = value }
        }
        return out
    }

    static func load(file: URL = envFileURL, environment: [String: String] = ProcessInfo.processInfo.environment) -> EnvConfig {
        var values: [String: String] = [:]
        if let text = try? String(contentsOf: file, encoding: .utf8) { values = parse(text) }
        for (k, v) in environment where k.hasPrefix("GHOSTTYPE_") { values[k] = v }
        return EnvConfig(values: values)
    }

    /// URL du serveur : uniquement une adresse de boucle locale. Toute autre adresse est refusée.
    var serverURL: Result<URL, EnvError> {
        guard let raw = values["GHOSTTYPE_LLM_URL"], !raw.isEmpty else { return .failure(.missing) }
        guard let url = URL(string: raw), let scheme = url.scheme?.lowercased(), ["http", "https"].contains(scheme),
              let host = url.host?.lowercased() else { return .failure(.invalid) }
        guard ["127.0.0.1", "localhost", "::1"].contains(host) else { return .failure(.notLoopback(host)) }
        return .success(url)
    }

    /// Jetons : bornés à 1…16 quoi qu'écrive le fichier.
    var maxTokens: Int { min(16, max(1, Int(values["GHOSTTYPE_LLM_MAX_TOKENS"] ?? "") ?? 12)) }
    /// Échéance : 50…250 ms (250 par défaut ; jamais plus).
    var timeoutMs: Int { min(250, max(50, Int(values["GHOSTTYPE_LLM_TIMEOUT_MS"] ?? "") ?? 250)) }
}

enum EnvError: Error, Equatable {
    case missing, invalid, notLoopback(String)
    var message: String {
        switch self {
        case .missing: return "GHOSTTYPE_LLM_URL absent du fichier .env"
        case .invalid: return "GHOSTTYPE_LLM_URL n’est pas une URL http(s) valide"
        case .notLoopback(let h): return "Hôte « \(h) » refusé : seules les adresses locales (127.0.0.1, localhost, ::1) sont autorisées"
        }
    }
}

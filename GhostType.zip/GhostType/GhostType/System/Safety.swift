import AppKit
import Carbon.HIToolbox

/// Pourquoi une prédiction a été ignorée (affiché dans le menu, jamais envoyé nulle part).
enum SkipReason: String {
    case disabled, noPermission, secureInput, secureField, deniedApp, unsupportedApp, unsupportedElement
    case selection, notAtLineEnd, noContext, noCaret, tooLarge, ownApp, noProvider

    var label: String {
        switch self {
        case .disabled: return "GhostType est désactivé"
        case .noPermission: return "Autorisations manquantes"
        case .secureInput: return "Saisie sécurisée active : aucune lecture"
        case .secureField: return "Champ de mot de passe : ignoré"
        case .deniedApp: return "Application dans la liste de refus"
        case .unsupportedApp: return "Application non prise en charge (navigateur, Electron, terminal)"
        case .unsupportedElement: return "Champ non pris en charge"
        case .selection: return "Du texte est sélectionné"
        case .notAtLineEnd: return "Le curseur n’est pas en fin de ligne"
        case .noContext: return "Pas assez de texte"
        case .noCaret: return "Position du curseur indisponible"
        case .tooLarge: return "Texte trop long"
        case .ownApp: return "Fenêtre de GhostType"
        case .noProvider: return "Moteur non configuré"
        }
    }
}

enum Safety {
    /// Liste de refus par défaut (modifiable dans l'application) : gestionnaires de mots de passe, etc.
    static let defaultDenylist: [String] = [
        "com.apple.keychainaccess", "com.apple.Passwords",
        "com.1password.1password", "com.agilebits.onepassword7", "com.agilebits.onepassword-osx",
        "com.bitwarden.desktop", "com.dashlane.dashlanephonefinal", "org.keepassxc.keepassxc",
    ]

    /// Hors périmètre : terminaux et navigateurs (liste fixe, non modifiable).
    private static let unsupportedIDs: Set<String> = [
        "com.apple.Terminal", "com.googlecode.iterm2", "dev.warp.Warp-Stable", "net.kovidgoyal.kitty",
        "com.github.wez.wezterm", "io.alacritty", "com.mitchellh.ghostty", "co.zeit.hyper",
        "com.apple.Safari", "com.apple.SafariTechnologyPreview",
        "com.google.Chrome", "com.google.Chrome.canary", "org.chromium.Chromium",
        "com.microsoft.edgemac", "com.brave.Browser", "company.thebrowser.Browser", "com.vivaldi.Vivaldi",
        "com.operasoftware.Opera", "org.mozilla.firefox", "org.mozilla.nightly",
        "com.microsoft.VSCode", "com.microsoft.VSCodeInsiders", "com.todesktop.230313mzl4w4u92",
    ]

    private static var cache: [String: Bool] = [:]

    /// Application non prise en charge : liste fixe, ou application Electron / Chromium détectée dans son bundle.
    static func isUnsupportedApp(bundleID: String) -> Bool {
        if unsupportedIDs.contains(bundleID) || bundleID.hasPrefix("org.mozilla.") { return true }
        if let cached = cache[bundleID] { return cached }
        var result = false
        if let url = NSWorkspace.shared.urlForApplication(withBundleIdentifier: bundleID) {
            let frameworks = url.appendingPathComponent("Contents/Frameworks")
            let names = (try? FileManager.default.contentsOfDirectory(atPath: frameworks.path)) ?? []
            result = names.contains { n in
                let l = n.lowercased()
                return l.contains("electron framework") || l.contains("chromium embedded")
                    || (l.hasSuffix("framework.framework") && ["chrome", "chromium", "edge", "brave", "vivaldi", "opera"].contains { l.contains($0) })
            }
        }
        cache[bundleID] = result
        return result
    }

    static var secureInputActive: Bool { IsSecureEventInputEnabled() }
}

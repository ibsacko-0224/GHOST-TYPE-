import AppKit
import ApplicationServices

struct TypingContext {
    let before: String          // 200 derniers caractères avant le curseur
    let caretRect: CGRect       // coordonnées écran « Accessibilité » (origine en haut à gauche de l'écran principal)
    let bundleID: String?
}

enum FocusResult {
    case ok(TypingContext)
    case skip(SkipReason)
}

/// Lecture seule de l'élément qui a le focus, via l'API d'accessibilité. N'écrit jamais dans l'application cible.
enum FocusReader {
    static let contextLength = 200
    private static let maxChars = 200_000
    private static let textRoles: Set<String> = ["AXTextField", "AXTextArea", "AXComboBox"]
    private static let system = AXUIElementCreateSystemWide()

    /// Évite de bloquer la frappe si l'application cible ne répond pas.
    static func configure() { AXUIElementSetMessagingTimeout(system, 0.15) }

    private static func attr(_ el: AXUIElement, _ name: String) -> CFTypeRef? {
        var v: CFTypeRef?
        return AXUIElementCopyAttributeValue(el, name as CFString, &v) == .success ? v : nil
    }

    private static func cfRange(_ el: AXUIElement, _ name: String) -> CFRange? {
        guard let v = attr(el, name), CFGetTypeID(v) == AXValueGetTypeID() else { return nil }
        var r = CFRange()
        return AXValueGetValue(v as! AXValue, .cfRange, &r) ? r : nil
    }

    private static func bounds(_ el: AXUIElement, _ range: CFRange) -> CGRect? {
        var r = range
        guard let axRange = AXValueCreate(.cfRange, &r) else { return nil }
        var out: CFTypeRef?
        guard AXUIElementCopyParameterizedAttributeValue(el, "AXBoundsForRange" as CFString, axRange, &out) == .success,
              let out, CFGetTypeID(out) == AXValueGetTypeID() else { return nil }
        var rect = CGRect.zero
        return AXValueGetValue(out as! AXValue, .cgRect, &rect) ? rect : nil
    }

    /// `allow` : décision de l'appelant (liste de refus, apps non prises en charge) pour un identifiant de bundle.
    static func read(allow: (String?) -> SkipReason?) -> FocusResult {
        guard AXIsProcessTrusted() else { return .skip(.noPermission) }
        guard let focusedRef = attr(system, "AXFocusedUIElement"), CFGetTypeID(focusedRef) == AXUIElementGetTypeID() else {
            return .skip(.unsupportedElement)
        }
        let el = focusedRef as! AXUIElement

        // Propriétaire réel du champ (peut différer de l'application au premier plan)
        var pid: pid_t = 0
        AXUIElementGetPid(el, &pid)
        let owner = NSRunningApplication(processIdentifier: pid)?.bundleIdentifier
        if let reason = allow(owner) { return .skip(reason) }

        // Sécurité d'abord : rôle / sous-rôle avant toute lecture de valeur
        let role = attr(el, "AXRole") as? String
        let subrole = attr(el, "AXSubrole") as? String
        if role == "AXSecureTextField" || subrole == "AXSecureTextField" { return .skip(.secureField) }
        guard let role, textRoles.contains(role) else { return .skip(.unsupportedElement) }

        // Contenu web (Chrome, Electron, Safari…) : attributs DOM présents → hors périmètre
        var names: CFArray?
        if AXUIElementCopyAttributeNames(el, &names) == .success, let list = names as? [String],
           list.contains(where: { $0.hasPrefix("AXDOM") }) { return .skip(.unsupportedElement) }

        if let n = attr(el, "AXNumberOfCharacters") as? Int, n > maxChars { return .skip(.tooLarge) }
        guard let value = attr(el, "AXValue") as? String else { return .skip(.unsupportedElement) }
        guard let sel = cfRange(el, "AXSelectedTextRange") else { return .skip(.noCaret) }
        guard sel.length == 0 else { return .skip(.selection) }

        let ns = value as NSString
        let loc = sel.location
        guard loc >= 0, loc <= ns.length else { return .skip(.noCaret) }
        if loc < ns.length {                       // du texte après le curseur sur la même ligne : on se tait
            let next = ns.character(at: loc)
            if next != 10 && next != 13 { return .skip(.notAtLineEnd) }
        }

        let start = max(0, loc - contextLength)
        let span = ns.rangeOfComposedCharacterSequences(for: NSRange(location: start, length: loc - start))
        let before = ns.substring(with: span)
        guard !before.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return .skip(.noContext) }

        // Rectangle du curseur : plage vide, sinon bord droit du caractère précédent
        var rect = bounds(el, CFRange(location: loc, length: 0))
        if rect == nil || rect!.height <= 0 {
            guard loc > 0, let prev = bounds(el, CFRange(location: loc - 1, length: 1)), prev.height > 0 else { return .skip(.noCaret) }
            rect = CGRect(x: prev.maxX, y: prev.minY, width: 0, height: prev.height)
        }
        return .ok(TypingContext(before: before, caretRect: rect!, bundleID: owner))
    }
}

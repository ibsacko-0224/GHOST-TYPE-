import AppKit

/// Panneau sans bordure, non activant, transparent aux clics : ne vole jamais le focus à l'application cible.
final class GhostPanel: NSPanel {
    override var canBecomeKey: Bool { false }
    override var canBecomeMain: Bool { false }
}

@MainActor
final class GhostOverlay {
    private let panel: GhostPanel
    private let label = NSTextField(labelWithString: "")

    init() {
        panel = GhostPanel(contentRect: .zero, styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: true)
        panel.isOpaque = false
        panel.backgroundColor = .clear
        panel.hasShadow = false
        panel.level = .popUpMenu
        panel.ignoresMouseEvents = true
        panel.hidesOnDeactivate = false
        panel.isReleasedWhenClosed = false
        panel.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .stationary, .ignoresCycle]
        label.isBordered = false
        label.drawsBackground = false
        label.isEditable = false
        label.isSelectable = false
        label.lineBreakMode = .byClipping
        label.maximumNumberOfLines = 1
        panel.contentView = label
    }

    /// `caret` en coordonnées « Accessibilité » (origine en haut à gauche de l'écran principal).
    func show(_ text: String, caret: CGRect) {
        label.font = .systemFont(ofSize: max(10, min(40, caret.height * 0.78)))
        label.textColor = NSColor(white: 0.55, alpha: 0.9)             // gris clair
        label.stringValue = text
        label.sizeToFit()
        let primaryHeight = NSScreen.screens.first?.frame.height ?? 0
        let bottomY = primaryHeight - caret.maxY                          // conversion vers les coordonnées Cocoa
        let h = label.frame.height
        let origin = NSPoint(x: caret.minX + 1, y: bottomY + (caret.height - h) / 2)
        panel.setFrame(NSRect(origin: origin, size: label.frame.size), display: true)
        panel.orderFrontRegardless()
    }

    func hide() { panel.orderOut(nil) }
}

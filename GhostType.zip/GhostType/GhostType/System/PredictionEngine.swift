import AppKit
import ApplicationServices

/// Orchestre la boucle : frappe → délai de 120 ms → lecture AX → prédiction → texte fantôme → Tab / Échap.
@MainActor
final class PredictionEngine {
    unowned let model: AppModel
    let ngram: NGramProvider
    private var server: LocalServerProvider?
    private let overlay = GhostOverlay()
    private let gate: TapGate
    private let tap: KeyTap
    private var debounceTask: Task<Void, Never>?
    private var inflight: Task<Void, Never>?
    private var generation = 0
    private var current: (text: String, bundleID: String?)?
    private var mouseMonitor: Any?
    private var appObserver: NSObjectProtocol?

    static let debounceNanos: UInt64 = 120_000_000

    init(model: AppModel, ngram: NGramProvider) {
        self.model = model
        self.ngram = ngram
        let g = TapGate()
        self.gate = g
        self.tap = KeyTap(gate: g)
        FocusReader.configure()
        tap.onKey = { @Sendable [weak self] in Task { @MainActor in self?.keyPressed() } }
        tap.onTab = { @Sendable [weak self] in Task { @MainActor in self?.accept() } }
        tap.onEscape = { @Sendable [weak self] in Task { @MainActor in self?.dismiss() } }
        // Un clic ou un changement d'application invalide la suggestion affichée.
        mouseMonitor = NSEvent.addGlobalMonitorForEvents(matching: [.leftMouseDown, .rightMouseDown]) { [weak self] _ in
            Task { @MainActor in self?.invalidate() }
        }
        appObserver = NSWorkspace.shared.notificationCenter.addObserver(
            forName: NSWorkspace.didActivateApplicationNotification, object: nil, queue: .main) { [weak self] _ in
            Task { @MainActor in self?.invalidate() }
        }
        reloadServer()
    }

    // MARK: Cycle de vie

    /// Appelée régulièrement : démarre/arrête le tap selon l'activation et les autorisations.
    func sync() {
        if model.enabled {
            if !tap.isRunning { tap.start() }
        } else if tap.isRunning {
            tap.stop()                // désactivé = plus aucune observation du clavier
            invalidate()
        }
    }

    var tapRunning: Bool { tap.isRunning }

    func reloadServer() {
        switch EnvConfig.load().serverURL {
        case .success(let url):
            let cfg = EnvConfig.load()
            server = LocalServerProvider(endpoint: url, maxTokens: cfg.maxTokens, deadlineMs: cfg.timeoutMs)
            model.envMessage = "Serveur local : \(url.absoluteString) (≤ \(cfg.maxTokens) jetons, \(cfg.timeoutMs) ms)"
        case .failure(let e):
            server = nil
            model.envMessage = e.message
        }
    }

    // MARK: Boucle principale

    private func invalidate() {
        generation += 1
        debounceTask?.cancel()
        inflight?.cancel()
        hideSuggestion()
    }

    private func hideSuggestion() {
        current = nil
        gate.suggestionVisible = false
        overlay.hide()
    }

    private func keyPressed() {
        invalidate()
        guard model.enabled else { return }
        let gen = generation
        debounceTask = Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: PredictionEngine.debounceNanos)
            guard !Task.isCancelled, let self, gen == self.generation else { return }
            self.predict(generation: gen)
        }
    }

    private func predict(generation gen: Int) {
        if Safety.secureInputActive { model.note(.secureInput); return }
        guard let provider = activeProvider() else { model.note(.noProvider); return }

        let front = NSWorkspace.shared.frontmostApplication?.bundleIdentifier
        if let reason = model.skipReason(forBundle: front) { model.note(reason); return }

        switch FocusReader.read(allow: { model.skipReason(forBundle: $0) }) {
        case .skip(let reason):
            model.note(reason)
        case .ok(let ctx):
            model.note(nil)
            inflight = Task { @MainActor [weak self] in
                let raw: String?
                do { raw = try await provider.complete(context: ctx.before) } catch { return }  // expiration / annulation : silence
                guard !Task.isCancelled, let self, gen == self.generation,
                      !Safety.secureInputActive,
                      let text = raw.flatMap({ Suggestion.clean($0, context: ctx.before) }) else { return }
                self.current = (text, ctx.bundleID)
                self.gate.suggestionVisible = true
                self.overlay.show(text, caret: ctx.caretRect)
            }
        }
    }

    private func activeProvider() -> PredictionProvider? {
        switch model.providerKind {
        case .ngram: return ngram
        case .localServer: return server
        }
    }

    // MARK: Tab / Échap

    private func accept() {
        guard let c = current else { return }
        hideSuggestion()
        generation += 1
        gate.insertingUntil = CFAbsoluteTimeGetCurrent() + 0.3
        TextInserter.insert(c.text)
    }

    private func dismiss() {
        generation += 1
        debounceTask?.cancel()
        inflight?.cancel()
        hideSuggestion()
    }
}
